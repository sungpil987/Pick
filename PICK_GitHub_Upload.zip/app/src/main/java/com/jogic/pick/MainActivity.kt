package com.jogic.pick

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PickApp() }
    }
}

private data class Game(val id: Int, val emoji: String, val title: String, val subtitle: String)

private val games = listOf(
    Game(1,"🚚","배달 시킬까?","오늘은 시켜 먹을까 말까"),
    Game(2,"🍽️","음식 종류 뽑기","한식부터 일식까지"),
    Game(3,"🍜","메뉴 뽑기","오늘 먹을 메뉴 결정"),
    Game(4,"🥤","사이드 메뉴","메인 메뉴에 곁들일 것"),
    Game(5,"🌙","야식 추천","밤에 당기는 메뉴"),
    Game(6,"📺","유튜브 선택권","오늘 리모컨 주인 정하기"),
    Game(7,"🎬","영화 고르기","장르부터 랜덤 픽"),
    Game(8,"✊","가위바위보","승부는 운에 맡겨"),
    Game(9,"💑","데이트 추천","오늘 뭐 하고 놀지"),
    Game(10,"🧹","집안일 담당","누가 할지 정해보자"),
    Game(11,"🔥","진실 혹은 도전","둘이서 즐기는 게임"),
    Game(12,"🎁","선물 아이디어","선물 고민 끝"),
    Game(13,"🔮","오늘의 예/아니오","고민을 랜덤으로"),
    Game(14,"✨","오늘의 운세","가볍게 보는 한 줄 운세"),
    Game(15,"🎯","커스텀 룰렛","직접 항목을 넣고 돌리기"),
    Game(16,"🎲","주사위","1부터 6까지"),
    Game(17,"🛒","주문 순서","누가 먼저 주문할까"),
    Game(18,"⚡","오늘의 미션","소소한 미션 하나"),
    Game(19,"👤","이름 뽑기","후보 중 한 명 선택"),
    Game(20,"🍀","로또 6/45","실제 방식으로 번호 생성")
)

private val bg = Color(0xFF101116)
private val panel = Color(0xFF1C1E27)
private val accent = Color(0xFFB8F36B)
private val muted = Color(0xFF9A9EAC)

@Composable
fun PickApp() {
    var selected by remember { mutableStateOf<Game?>(null) }
    var result by remember { mutableStateOf("") }
    var custom by remember { mutableStateOf("") }
    var names by remember { mutableStateOf("나, 상대") }
    var rps by remember { mutableStateOf("가위") }

    MaterialTheme(colorScheme = darkColorScheme(
        background = bg, surface = panel, primary = accent,
        onBackground = Color.White, onSurface = Color.White,
        onPrimary = Color(0xFF111111)
    )) {
        Scaffold(containerColor = bg) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(22.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("PICK", color = accent, fontSize = 32.sp, fontWeight = FontWeight.Black)
                    Text("!", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.weight(1f))
                    Text("DECIDE FOR YOU", color = muted, fontSize = 10.sp, letterSpacing = 2.sp)
                }
                Text("고민은 여기까지. 골라줄게.", color = Color.White, fontSize = 21.sp,
                    fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp))
                Text("혼자서도, 둘이서도 가볍게 즐기는 랜덤 게임 20가지",
                    color = muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp, bottom = 18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("ALL GAMES", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                    Text("20 FUNCTIONS", color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(12.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    verticalArrangement = Arrangement.spacedBy(11.dp),
                    horizontalArrangement = Arrangement.spacedBy(11.dp),
                    contentPadding = PaddingValues(bottom = 28.dp)
                ) {
                    items(games) { game ->
                        Column(
                            Modifier.fillMaxWidth().height(122.dp)
                                .background(panel, RoundedCornerShape(18.dp))
                                .clickable {
                                    selected = game
                                    result = ""
                                }.padding(14.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(game.emoji, fontSize = 25.sp)
                            Column {
                                Text(game.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(game.subtitle, color = muted, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                }
            }
        }

        selected?.let { game ->
            AlertDialog(
                onDismissRequest = { selected = null },
                containerColor = panel,
                title = {
                    Column {
                        Text("${game.emoji}  ${game.title}", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(game.subtitle, color = muted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
                    }
                },
                text = {
                    Column {
                        when (game.id) {
                            15 -> {
                                Text("룰렛 항목을 쉼표(,)로 구분해서 입력해.", color = muted, fontSize = 12.sp)
                                Spacer(Modifier.height(10.dp))
                                BasicTextField(value = custom, onValueChange = { custom = it },
                                    modifier = Modifier.fillMaxWidth().background(bg, RoundedCornerShape(10.dp)).padding(12.dp),
                                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                                    decorationBox = { inner -> if (custom.isEmpty()) Text("예: 치킨, 피자, 햄버거", color = muted); inner() })
                            }
                            19 -> {
                                Text("이름 후보를 쉼표(,)로 구분해 입력해.", color = muted, fontSize = 12.sp)
                                Spacer(Modifier.height(10.dp))
                                BasicTextField(value = names, onValueChange = { names = it },
                                    modifier = Modifier.fillMaxWidth().background(bg, RoundedCornerShape(10.dp)).padding(12.dp),
                                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp))
                            }
                            8 -> {
                                Text("네가 낼 패를 선택해.", color = muted, fontSize = 12.sp)
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("가위","바위","보").forEach { choice ->
                                        FilterChip(selected = rps == choice, onClick = { rps = choice }, label = { Text(choice) })
                                    }
                                }
                            }
                            20 -> Text("1부터 45까지 중복 없이 6개 번호와 보너스 번호를 뽑아.", color = muted, fontSize = 12.sp)
                            else -> Text("버튼을 눌러 랜덤으로 결정해봐.", color = muted, fontSize = 12.sp)
                        }
                        if (result.isNotBlank()) {
                            Spacer(Modifier.height(18.dp))
                            Box(Modifier.fillMaxWidth().background(bg, RoundedCornerShape(14.dp)).padding(16.dp),
                                contentAlignment = Alignment.Center) {
                                Text(result, color = accent, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = { result = pickResult(game.id, custom, names, rps) },
                        colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black)) {
                        Text(if (result.isEmpty()) "뽑기!" else "다시 뽑기", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selected = null }) { Text("닫기", color = muted) }
                }
            )
        }
    }
}

private fun pickResult(id: Int, custom: String, names: String, rps: String): String {
    val pick: (List<String>) -> String = { it.random() }
    return when (id) {
        1 -> pick(listOf("오늘은 배달 가자! 🍗", "오늘은 집밥 먹자! 🥘"))
        2 -> pick(listOf("한식 🍚","중식 🥟","일식 🍣","양식 🍝","분식 🍜","멕시칸 🌮","동남아 🍲"))
        3 -> pick(listOf("김치찌개","마라탕","돈가스","제육볶음","초밥","파스타","햄버거","쌀국수","순두부찌개","치킨","피자","냉면"))
        4 -> pick(listOf("감자튀김","치즈볼","만두","계란찜","주먹밥","콘샐러드","치킨너겟","웨지감자"))
        5 -> pick(listOf("라면","닭발","족발","떡볶이","곱창","토스트","아이스크림","핫도그"))
        6 -> pick(listOf("네가 오늘 유튜브 선택!","상대가 오늘 유튜브 선택!"))
        7 -> pick(listOf("액션 🎬","코미디 😂","스릴러 🔪","로맨스 ❤️","SF 🚀","애니메이션 🌟","공포 👻","다큐멘터리 🎥"))
        8 -> {
            val theirs = listOf("가위","바위","보").random()
            val outcome = when {
                theirs == rps -> "무승부!"
                (rps == "가위" && theirs == "보") || (rps == "바위" && theirs == "가위") || (rps == "보" && theirs == "바위") -> "네가 이겼다!"
                else -> "상대 승리!"
            }
            "너: $rps  /  상대: $theirs\n$outcome"
        }
        9 -> pick(listOf("동네 산책하며 카페 가기","보드게임 카페","맛집 탐방","드라이브","방탈출","집에서 영화 데이트","사진 찍으러 가기","야경 보러 가기"))
        10 -> pick(listOf("설거지 담당!","분리수거 담당!","청소기 담당!","화장실 청소 담당!","오늘은 같이 10분 청소!"))
        11 -> pick(listOf("진실: 최근 가장 설렜던 순간은?","진실: 서로의 첫인상은?","진실: 지금 가장 고마운 점은?","도전: 10초 동안 웃기","도전: 상대 칭찬 3개 하기","도전: 애교 한 번 보여주기"))
        12 -> pick(listOf("취향 맞춤 간식","작은 향수","포토카드/사진 액자","실용적인 텀블러","손편지","커플 키링","취미 관련 소품"))
        13 -> pick(listOf("YES. 해봐!","NO. 오늘은 참자.","조금 더 생각해봐."))
        14 -> pick(listOf("작은 행운이 찾아올지도!","미뤘던 일을 시작하기 좋은 날.","주변 사람에게 먼저 연락해봐.","오늘은 무리하지 말고 쉬어가자.","뜻밖의 칭찬을 들을 수 있어!"))
        15 -> {
            val options = custom.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            if (options.size < 2) "항목을 2개 이상 입력해줘." else "🎯 ${pick(options)}"
        }
        16 -> "🎲 ${Random.nextInt(1, 7)}"
        17 -> pick(listOf("네가 먼저 주문!","상대가 먼저 주문!"))
        18 -> pick(listOf("물 한 컵 마시기 💧","5분 산책하기 🚶","고마운 사람에게 연락하기 💬","책 5페이지 읽기 📖","책상 5분 정리하기 🧹","좋아하는 노래 한 곡 듣기 🎧","스트레칭 3분 하기 🧘"))
        19 -> {
            val options = names.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            if (options.isEmpty()) "이름을 입력해줘." else "오늘의 선택: ${pick(options)}"
        }
        20 -> {
            val nums = (1..45).shuffled().take(7).sorted()
            "🍀 ${nums.take(6).joinToString("  ")}\n보너스 번호: ${nums.last()}"
        }
        else -> "다시 시도해줘!"
    }
}
