# PICK! Android 2.0

PICK! 2.0 is a compact Korean decision game app built with Kotlin and Jetpack Compose.

## Included games
- Food decision flow: delivery yes/no → cuisine → menu → side yes/no
- Today's fortune: 30 fortune messages plus lucky item, color and number
- YES OR NO
- Custom roulette with suspenseful decelerating draw animation
- Lotto 6/45: reveal six unique numbers one at a time, then show the completed set

## Build
Use Android Studio or run `gradle assembleDebug` with Android SDK installed and Gradle 8.9.

Version: 2.0 (versionCode 2)
