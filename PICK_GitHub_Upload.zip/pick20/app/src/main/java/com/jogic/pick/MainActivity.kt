package com.jogic.pick

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PickApp() }
    }
}

private data class Game(val id: String, val emoji: String, val title: String, val subtitle: String)
private val games = listOf(
    Game("food", "🍔", "오늘 뭐 먹지?", "배달부터 메뉴와 사이드까지 한 번에"),
    Game("fortune", "🍀", "오늘의 운세", "오늘의 행운을 확인해 봐"),
    Game("yesno", "🔮", "YES OR NO", "고민을 랜덤으로 결정"),
    Game("wheel", "🎡", "커스텀 룰렛", "원하는 항목을 직접 넣고 돌리기"),
    Game("lotto", "🎱", "로또 6/45", "번호를 하나씩 뽑아 6개 완성")
)

private val bg = Color(0xFF101116)
private val panel = Color(0xFF1C1E27)
private val panel2 = Color(0xFF252936)
private val accent = Color(0xFFB8F36B)
private val muted = Color(0xFF9A9EAC)
private val white = Color(0xFFF7F8FA)

private val cuisineOptions = listOf("한식 🍚", "중식 🥟", "일식 🍣", "양식 🍝", "분식 🍜", "아시안 🍲", "멕시칸 🌮")
private val menuMap = mapOf(
    "한식 🍚" to listOf("김치찌개", "제육볶음", "순두부찌개", "불고기", "비빔밥", "국밥", "된장찌개", "찜닭", "닭갈비", "보쌈"),
    "중식 🥟" to listOf("짜장면", "짬뽕", "탕수육", "마파두부덮밥", "볶음밥", "마라탕", "마라샹궈", "깐풍기"),
    "일식 🍣" to listOf("초밥", "돈카츠", "라멘", "우동", "규동", "가츠동", "연어덮밥", "냉모밀"),
    "양식 🍝" to listOf("토마토 파스타", "크림 파스타", "피자", "스테이크", "햄버거", "리조또", "라자냐"),
    "분식 🍜" to listOf("떡볶이", "순대", "김밥", "라볶이", "쫄면", "튀김", "어묵"),
    "아시안 🍲" to listOf("쌀국수", "팟타이", "분짜", "나시고랭", "월남쌈", "똠얌꿍"),
    "멕시칸 🌮" to listOf("타코", "부리또", "퀘사디아", "나초 플래터", "파히타")
)
private val fortunes = listOf(
    "작은 행운이 찾아오는 날. 평소 지나치던 기회를 눈여겨봐.",
    "오늘은 시작하기 좋은 날이야. 미뤄둔 일을 10분만 해보자.",
    "서두르지 않으면 오히려 일이 술술 풀릴 거야.",
    "뜻밖의 연락이나 반가운 소식이 찾아올 수 있어.",
    "오늘의 행운은 사람에게서 와. 먼저 따뜻하게 인사해 봐.",
    "새로운 선택이 좋은 자극이 될 수 있어. 작은 변화를 줘봐.",
    "지출은 한 번 더 생각하고 결제하면 만족도가 높아질 거야.",
    "평소보다 집중력이 좋은 날. 중요한 일부터 처리해 봐.",
    "잠깐 쉬어가는 것이 오히려 가장 빠른 길일 수 있어.",
    "오늘은 네 취향을 믿어도 좋아. 마음이 가는 쪽을 골라봐.",
    "사소한 친절이 생각보다 큰 기쁨으로 돌아올 수 있어.",
    "새로운 아이디어가 떠오르면 바로 메모해 둬.",
    "오늘은 정리와 정돈에 운이 따르는 날. 주변부터 가볍게 정리해 봐.",
    "뜻밖의 발견이 하루를 즐겁게 만들 거야. 주변을 잘 살펴봐.",
    "금전운은 안정적인 흐름. 충동구매만 조심하면 좋아.",
    "대화운이 좋아. 먼저 말을 걸면 좋은 분위기가 만들어질 거야.",
    "작은 목표를 하나 끝내면 자신감이 올라갈 거야.",
    "오늘은 무리한 승부보다 안전한 선택이 유리해.",
    "기다리던 일에 작은 진전이 생길 수 있어.",
    "몸과 마음의 리듬을 맞춰봐. 물 한 잔과 스트레칭부터.",
    "연애운 상승! 솔직하고 다정한 표현이 좋은 결과를 부를 거야.",
    "오늘의 키워드는 여유. 조급해하지 말고 네 속도로 가자.",
    "집중이 잘 되는 날이야. 휴대폰을 잠깐 멀리 둬봐.",
    "예상 밖의 선택지가 더 마음에 들 수도 있어. 열린 마음을 가져봐.",
    "오늘은 주변의 조언에서 쓸 만한 힌트를 얻을 수 있어.",
    "작은 소비보다 오래 남는 경험에 투자하면 만족스러울 거야.",
    "마무리 운이 좋아. 미완성으로 남은 일을 끝내보자.",
    "오늘은 네 편이 되어주는 사람이 있다는 걸 기억해.",
    "평소와 다른 길을 선택해 봐. 재미있는 일이 생길지도 몰라.",
    "운은 준비된 사람에게 찾아와. 기본을 차근차근 챙겨보자."
)
private val luckyItems = listOf("초록색 소품", "이어폰", "텀블러", "좋아하는 향", "동전", "작은 메모장", "편한 신발", "손목시계", "키링", "따뜻한 음료")
private val luckyColors = listOf("라임 그린", "네이비", "아이보리", "하늘색", "버건디", "실버", "라벤더", "블랙")

@Composable
fun PickApp() {
    var selected by remember { mutableStateOf<String?>(null) }
    MaterialTheme(colorScheme = darkColorScheme(background = bg, surface = panel, primary = accent, onBackground = white, onSurface = white, onPrimary = Color(0xFF111111))) {
        if (selected == null) HomeScreen(onSelect = { selected = it }) else {
            when (selected) {
                "food" -> FoodFlow(onBack = { selected = null })
                "fortune" -> FortuneScreen(onBack = { selected = null })
                "yesno" -> YesNoScreen(onBack = { selected = null })
                "wheel" -> WheelScreen(onBack = { selected = null })
                "lotto" -> LottoScreen(onBack = { selected = null })
            }
        }
    }
}

@Composable
private fun HomeScreen(onSelect: (String) -> Unit) {
    Column(Modifier.fillMaxSize().background(bg).padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(30.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("PICK", color = accent, fontSize = 34.sp, fontWeight = FontWeight.Black)
            Text("!", color = white, fontSize = 34.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.weight(1f))
            Text("VERSION 2.0", color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        }
        Text("고민은 여기까지. 골라줄게.", color = white, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
        Text("돌리는 순간부터 결과까지, 더 짜릿하게.", color = muted, fontSize = 13.sp, modifier = Modifier.padding(top = 7.dp, bottom = 24.dp))
        Text("PICK YOUR GAME", color = white, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(13.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
            items(games) { game ->
                Column(
                    Modifier.fillMaxWidth().height(if (game.id == "food") 164.dp else 142.dp)
                        .background(panel, RoundedCornerShape(20.dp)).clickable { onSelect(game.id) }.padding(15.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(game.emoji, fontSize = 29.sp)
                    Column {
                        Text(game.title, color = white, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(game.subtitle, color = muted, fontSize = 10.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 5.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ScreenHeader(title: String, subtitle: String, onBack: () -> Unit) {
    Column {
        Text("‹  돌아가기", color = accent, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onBack() }.padding(vertical = 8.dp))
        Text(title, color = white, fontSize = 25.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 8.dp))
        Text(subtitle, color = muted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp, bottom = 18.dp))
    }
}

@Composable
private fun ScreenFrame(title: String, subtitle: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(bg).padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(22.dp))
        ScreenHeader(title, subtitle, onBack)
        content()
    }
}

@Composable
private fun SpinPicker(
    title: String,
    options: List<String>,
    buttonText: String = "운명의 버튼 누르기",
    onPicked: (String) -> Unit
) {
    var display by remember(options) { mutableStateOf("READY?") }
    var spinning by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(22.dp)).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title.uppercase(), color = muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth().height(118.dp).background(bg, RoundedCornerShape(18.dp)).border(1.dp, if (spinning) accent else panel2, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (spinning) "🎰  PICKING..." else "✦  YOUR PICK  ✦", color = if (spinning) accent else muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(9.dp))
                Text(display, color = if (spinning) white else accent, fontSize = 25.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(
            enabled = !spinning && options.isNotEmpty(),
            onClick = {
                if (options.isNotEmpty()) scope.launch {
                    spinning = true
                    val winner = options.random()
                    for (i in 0 until 26) {
                        display = options.random()
                        delay(35L + i * 9L)
                    }
                    display = winner
                    spinning = false
                    onPicked(winner)
                }
            },
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(15.dp),
            colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black, disabledContainerColor = panel2)
        ) { Text(if (spinning) "두근두근..." else buttonText, fontSize = 15.sp, fontWeight = FontWeight.Black) }
    }
}

@Composable
private fun FoodFlow(onBack: () -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    var delivery by remember { mutableStateOf("") }
    var cuisine by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf("") }
    var side by remember { mutableStateOf("") }
    ScreenFrame("오늘 뭐 먹지?", "배달 여부부터 메뉴와 사이드까지 순서대로 결정해 보자.", onBack) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            listOf("배달", "종류", "메뉴", "사이드").forEachIndexed { index, label ->
                val active = step == index
                Box(Modifier.weight(1f).height(34.dp).background(if (active) accent else panel, RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                    Text("${index + 1}. $label", color = if (active) Color.Black else muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        when (step) {
            0 -> SpinPicker("배달 시킬까?", listOf("배달 가자! 🛵", "오늘은 집밥! 🥘")) { picked ->
                delivery = picked
                if (picked.startsWith("배달")) step = 1 else step = 0
            }
            1 -> SpinPicker("음식 종류 뽑기", cuisineOptions) { cuisine = it; step = 2 }
            2 -> SpinPicker("메뉴 뽑기 · ${cuisine}", menuMap[cuisine] ?: menuMap.values.flatten()) { menu = it; step = 3 }
            3 -> SpinPicker("사이드 추가할까?", listOf("사이드 추가하자! 🍟", "사이드는 패스! 🙅"), "사이드 여부 뽑기") { side = it }
        }
        Spacer(Modifier.height(16.dp))
        if (delivery.isNotBlank() || cuisine.isNotBlank() || menu.isNotBlank() || side.isNotBlank()) {
            Column(Modifier.fillMaxWidth().background(panel2, RoundedCornerShape(18.dp)).padding(16.dp)) {
                Text("TODAY'S ORDER", color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                if (delivery.isNotBlank()) SummaryLine("배달", delivery)
                if (cuisine.isNotBlank()) SummaryLine("종류", cuisine)
                if (menu.isNotBlank()) SummaryLine("메뉴", menu)
                if (side.isNotBlank()) SummaryLine("사이드", side)
                if (delivery.startsWith("오늘은 집밥")) Text("배달 대신 집밥으로 결정했어! 다시 시작하고 싶으면 아래 버튼을 눌러줘.", color = muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { step = 0; delivery = ""; cuisine = ""; menu = ""; side = "" }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("처음부터 다시 뽑기", color = white) }
        }
        if (step == 0 && delivery.startsWith("오늘은 집밥")) {
            Spacer(Modifier.height(10.dp))
            Button(onClick = { step = 0; delivery = "" }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black)) { Text("다시 결정하기") }
        }
    }
}

@Composable
private fun SummaryLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(top = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = muted, fontSize = 12.sp, modifier = Modifier.width(48.dp))
        Text(value, color = white, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun FortuneScreen(onBack: () -> Unit) {
    var fortune by remember { mutableStateOf("") }
    var luckyItem by remember { mutableStateOf("") }
    var luckyColor by remember { mutableStateOf("") }
    var luckyNumber by remember { mutableIntStateOf(0) }
    ScreenFrame("오늘의 운세", "재미로 보는 랜덤 운세야. 좋은 기운만 챙겨가자!", onBack) {
        SpinPicker("오늘의 운세 뽑기", fortunes, "오늘의 운세 확인") {
            fortune = it
            luckyItem = luckyItems.random()
            luckyColor = luckyColors.random()
            luckyNumber = Random.nextInt(1, 100)
        }
        if (fortune.isNotBlank()) {
            Spacer(Modifier.height(14.dp))
            Column(Modifier.fillMaxWidth().background(panel2, RoundedCornerShape(18.dp)).padding(18.dp)) {
                Text("TODAY'S FORTUNE", color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Text(fortune, color = white, fontSize = 17.sp, fontWeight = FontWeight.Bold, lineHeight = 25.sp, modifier = Modifier.padding(top = 12.dp))
                DividerLine()
                SummaryLine("행운 아이템", luckyItem)
                SummaryLine("행운 컬러", luckyColor)
                SummaryLine("행운 숫자", luckyNumber.toString())
            }
        }
    }
}

@Composable
private fun DividerLine() { Spacer(Modifier.fillMaxWidth().padding(top = 15.dp).height(1.dp).background(Color(0xFF3A3E4A))) }

@Composable
private fun YesNoScreen(onBack: () -> Unit) {
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    ScreenFrame("YES OR NO", "고민을 떠올리고 운명에 맡겨봐.", onBack) {
        OutlinedTextField(value = question, onValueChange = { question = it; answer = "" }, label = { Text("무엇이 고민이야? (선택)") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = accent, focusedLabelColor = accent, cursorColor = accent))
        Spacer(Modifier.height(16.dp))
        SpinPicker("YES OR NO", listOf("YES ✨", "NO 🌙", "조금 더 생각해 봐 🤔"), "운명의 답 확인") { answer = it }
        if (answer.isNotBlank()) {
            Spacer(Modifier.height(14.dp))
            Column(Modifier.fillMaxWidth().background(panel2, RoundedCornerShape(16.dp)).padding(16.dp)) {
                if (question.isNotBlank()) Text("“$question”", color = muted, fontSize = 12.sp)
                Text(answer, color = accent, fontSize = 24.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 8.dp))
                Text("재미로 보는 랜덤 답변이야. 중요한 결정은 충분히 생각해서 해줘.", color = muted, fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

@Composable
private fun WheelScreen(onBack: () -> Unit) {
    var raw by remember { mutableStateOf("치킨, 피자, 햄버거, 떡볶이") }
    var winner by remember { mutableStateOf("") }
    ScreenFrame("커스텀 룰렛", "직접 후보를 입력하면 긴장감 있게 하나를 뽑아줄게.", onBack) {
        OutlinedTextField(value = raw, onValueChange = { raw = it; winner = "" }, label = { Text("항목 입력 (쉼표 또는 줄바꿈)") }, modifier = Modifier.fillMaxWidth(), minLines = 3, shape = RoundedCornerShape(14.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = accent, focusedLabelColor = accent, cursorColor = accent))
        val options = raw.split(',', '\n').map { it.trim() }.filter { it.isNotBlank() }.distinct()
        Text("현재 후보 ${options.size}개 · 최소 2개 필요", color = muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 10.dp))
        SpinPicker("CUSTOM ROULETTE", options, "룰렛 돌리기") { winner = it }
        if (winner.isNotBlank()) {
            Spacer(Modifier.height(14.dp))
            Text("🎯  $winner", color = accent, fontSize = 25.sp, fontWeight = FontWeight.Black, modifier = Modifier.fillMaxWidth().background(panel2, RoundedCornerShape(16.dp)).padding(20.dp), textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun LottoScreen(onBack: () -> Unit) {
    var pool by remember { mutableStateOf((1..45).shuffled().take(6)) }
    var numbers by remember { mutableStateOf(emptyList<Int>()) }
    ScreenFrame("로또 6/45", "번호를 하나씩 뽑아봐. 6개가 모이면 최종 조합을 공개해!", onBack) {
        Column(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(20.dp)).padding(16.dp)) {
            Text("LOTTO DRAW", color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                repeat(6) { index ->
                    val n = numbers.getOrNull(index)
                    Box(Modifier.weight(1f).aspectRatio(1f).background(if (n != null) ballColor(n) else panel2, CircleShape), contentAlignment = Alignment.Center) {
                        Text(n?.toString() ?: "?", color = if (n != null) Color(0xFF111111) else muted, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            if (numbers.size < 6) {
                SpinPicker("${numbers.size + 1}번째 번호 뽑기", (1..45).filterNot { it in numbers }.map { it.toString() }, "번호 하나 뽑기") { picked -> numbers = numbers + picked.toInt() }
            } else {
                Text("🎉  6개 번호 추첨 완료!", color = accent, fontSize = 18.sp, fontWeight = FontWeight.Black, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                Spacer(Modifier.height(10.dp))
                Text(numbers.sorted().joinToString("   "), color = white, fontSize = 22.sp, fontWeight = FontWeight.Black, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                Text("무작위로 생성한 번호이며 당첨을 예측하거나 보장하지 않아.", color = muted, fontSize = 10.sp, modifier = Modifier.padding(top = 9.dp), textAlign = TextAlign.Center)
            }
        }
        Spacer(Modifier.height(14.dp))
        OutlinedButton(onClick = { pool = (1..45).shuffled().take(6); numbers = emptyList() }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("새 게임 시작", color = white) }
    }
}

private fun ballColor(number: Int): Color = when (number) {
    in 1..10 -> Color(0xFFFFD34E)
    in 11..20 -> Color(0xFF6AB7FF)
    in 21..30 -> Color(0xFFFF7777)
    in 31..40 -> Color(0xFFAAAAAA)
    else -> Color(0xFF9BD85B)
}
