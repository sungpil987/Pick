# PICK! Android App

개인용 랜덤 선택 앱. 로그인, 계정, 서버 연결 없이 기기에서 실행됩니다.

## 포함 기능
배달 결정, 음식 종류, 메뉴, 사이드, 야식, 유튜브 선택권, 영화 장르, 가위바위보, 데이트 추천, 집안일 담당, 진실 혹은 도전, 선물 아이디어, 예/아니오, 오늘의 운세, 커스텀 룰렛, 주사위, 주문 순서, 오늘의 미션, 이름 뽑기, 로또 6/45.

## APK 자동 빌드
이 프로젝트는 GitHub Actions로 APK를 자동 빌드하도록 설정되어 있습니다.
저장소에 업로드한 뒤 **Actions → Build Android APK → Run workflow**를 실행하면 됩니다.
완료된 빌드의 **Artifacts**에서 `PICK-debug-apk`를 내려받을 수 있습니다.

직접 빌드하려면 Android Studio에서 프로젝트를 열고 `app`의 `assembleDebug` 작업을 실행하세요.
APK는 `app/build/outputs/apk/debug/app-debug.apk`에 생성됩니다.
